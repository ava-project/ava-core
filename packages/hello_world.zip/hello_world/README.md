# Hello world

An example of a plugin written in C++.


### commands

Name | Action
------------ | -------------
hello(string) | Say hello :)
