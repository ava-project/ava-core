# Firefox

AVA plugin to interact with Firefox web browser

### Commands

Name | Action
------------ | -------------
open(string) | Open the specified URL
type(string) | Search the query on youtube
maximize() | Maximize the window

### Requirements

selenium
