# SSH

Tom personal plugin to connect to hiw own server.


### Commands

Name | Action
------------ | -------------
connect() | Perform a connection through ssh to: 193.70.42.59
