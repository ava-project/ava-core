import subprocess

class Ping(object):
    "Ping plugin"
    pass
