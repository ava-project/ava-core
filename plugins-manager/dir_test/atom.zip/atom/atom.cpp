#include <iostream>

int main(void) { return std::cout << "C++!!!\n", 0; }
